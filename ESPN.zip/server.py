from flask import Flask,make_response,render_template, request, jsonify, json
import json,random
app = Flask(__name__)

@app.route("/top5/")
def hello():
    names=["name 1","name 2","name 3","name 4","name 5","name 6"]
    names_=[]
    for name in names:
        nam={}
        nam["name"]=name
        nam["avg"]=random.randint(10,200)
        nam["sr"]=random.randint(10,200)
        print nam
        names_.append(nam)

    #return json.dumps(names)
    #print names_
    return make_response(render_template('top5.html',data=names_),200)

@app.route("/")
def main():
    #headers = {'Content-Type': 'text/html'}
    #data=[{"teams":["kochi","chennai"]}]
    return make_response(render_template('index.html'),200)

if __name__ == "__main__":
    app.run()